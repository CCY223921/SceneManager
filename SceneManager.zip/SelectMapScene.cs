using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectMapScene : BaseScene
{
    public override void OnLoad(params object[] param0)
    {
        //������ͼ
        //SGUIManager.Instance.Load<SceneMapListUI>();
    }
}
